// JavaScript Document voor Showcase Arne Slabbinck

$( function() {
	
	
$('.subMenu').smint();


});